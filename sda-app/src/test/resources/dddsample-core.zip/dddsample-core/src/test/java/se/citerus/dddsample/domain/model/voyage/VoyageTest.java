package se.citerus.dddsample.domain.model.voyage;

import org.junit.Test;

import junit.framework.TestCase;

public class VoyageTest extends TestCase {

    @Test
    public void testVoyageNumber() {
        //TODO: Test goes here...
    }

    @Test
    public void testSchedule() {
        //TODO: Test goes here...
    }

    @Test
    public void testHashCode() {
        //TODO: Test goes here...
    }

    @Test
    public void testEquals() {
        //TODO: Test goes here...
    }

    @Test
    public void testSameIdentityAs() {
        //TODO: Test goes here...
    }

    @Test
    public void testToString() {
        //TODO: Test goes here...
    }

    @Test
    public void testAddMovement() {
        //TODO: Test goes here...
    }

    public void testBuild() {
        //TODO: Test goes here...
    }


}
