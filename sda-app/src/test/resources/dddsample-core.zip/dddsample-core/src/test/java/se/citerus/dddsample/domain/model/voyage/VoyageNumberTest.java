package se.citerus.dddsample.domain.model.voyage;

import org.junit.Test;

import junit.framework.TestCase;

public class VoyageNumberTest extends TestCase {

    @Test
    public void testEquals() {
        //TODO: Test goes here...
    }

    @Test
    public void testHashCode() {
        //TODO: Test goes here...
    }

    @Test
    public void testSameValueAs() {
        //TODO: Test goes here...
    }

    @Test
    public void testCopy() {
        //TODO: Test goes here...
    }

    @Test
    public void testToString() {
        //TODO: Test goes here...
    }

    @Test
    public void testIdString() {
        //TODO: Test goes here...
    }


}
