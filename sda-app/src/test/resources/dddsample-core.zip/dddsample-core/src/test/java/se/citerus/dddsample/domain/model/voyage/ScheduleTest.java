package se.citerus.dddsample.domain.model.voyage;

import org.junit.Test;

public class ScheduleTest {

    @Test
    public void testCarrierMovements() {
        //TODO: Test goes here...
    }

    @Test
    public void testSameValueAs() {
        //TODO: Test goes here...
    }

    @Test
    public void testCopy() {
        //TODO: Test goes here...
    }

    @Test
    public void testEquals() {
        //TODO: Test goes here...
    }

    @Test
    public void testHashCode() {
        //TODO: Test goes here...
    }


}
